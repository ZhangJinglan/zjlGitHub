<html>
<head>
  <style type="text/css">@import url("mystyle.css"); </style>
</head>

<body>
<nav>
<a href="Page1.php">Page 1</a>
<a href="Page2.php">Page 2</a>
<a href="Page3.php">Page 3</a>
</nav>

<h3>   a single stalk of plumegrass wilts.</h3>

</body>

</html>
